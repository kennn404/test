<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'flightsc_1' );

/** Database username */
define( 'DB_USER', 'flightsc_1' );

/** Database password */
define( 'DB_PASSWORD', 'k9i1bjfn*zr@' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define('DISABLE_WP_CRON', true);

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ':1bP-Fg_aIFkM/wykdaj=mGWKg*RW $#s#7O NoY|8ucfKSkNLPyjRPtLf0J0~wC' );
define( 'SECURE_AUTH_KEY',  'Fy7H=%>&?VaxDh;Ntz#z@Gq-EUua)snpoV4z?Hs6U4-F@%:<CMV(brKn5[~g9zU&' );
define( 'LOGGED_IN_KEY',    '|h-@U5O{U<-SR|4j-iBJ_K)k9yeB,| djDeZ{Qm:T:aN9kIOZn<G`Dau3A;#rCe)' );
define( 'NONCE_KEY',        'IR) g/NgThg]A^(fw$7y6a[B[.Oz[!d5>T!l1xdUo{*{Q[P-{@Uo$e.f&1Ie8=e7' );
define( 'AUTH_SALT',        ']+,jRJ{[ PM?|3}CH+-cRp^cJttYsItf6z+7Qso<2Uof{d`?PD@i;hurI.dDVeRk' );
define( 'SECURE_AUTH_SALT', 'q3w+f=7K&z M@Zb+<?U,FH]w:-rqKQk+1mN(4$U,.6c!xx:5$WWN<Y:=s^NQ7`X]' );
define( 'LOGGED_IN_SALT',   'kRn-};>[;1VIl!>4,B%U=dEDQHG|+@pp7Rodp{JvmIN-3 @9Asit}XLb[l!uTn)E' );
define( 'NONCE_SALT',       '^Zz29MF#-A)K=>87%RA|yfih+RN=gV~@b}kz$_;km1lf` bWw>+C%<.`4/Y4^Tq ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';